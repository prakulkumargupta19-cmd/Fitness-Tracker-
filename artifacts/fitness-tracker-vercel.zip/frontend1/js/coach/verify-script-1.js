

/* =========================================================
   API
========================================================= */

const API_BASE = window.FITNESS_API_BASE || "";


/* =========================================================
   ELEMENTS
========================================================= */

const otpInputs =
    document.querySelectorAll(".otp-input");

const verifyButton =
    document.getElementById("verifyButton");

const resendButton =
    document.getElementById("resendButton");

const message =
    document.getElementById("message");

const timerElement =
    document.getElementById("timer");

const userEmail =
    document.getElementById("userEmail");


/* =========================================================
   GET RESET EMAIL
========================================================= */

const emailFromUrl =
    new URLSearchParams(window.location.search).get("email");

const email =
    (emailFromUrl ||
        sessionStorage.getItem("resetEmail") ||
        "")
    .trim()
    .toLowerCase();

if (email) {
    sessionStorage.setItem("resetEmail", email);
}


/*
 * If there is no email saved, the user should not
 * be able to continue with OTP verification.
 */

if (!email) {

    userEmail.textContent =
        "No email selected";

    verifyButton.disabled = true;

    showMessage(
        "No reset request was found. Please enter your email again.",
        "error"
    );

}


/* =========================================================
   MASK EMAIL
========================================================= */

function maskEmail(email) {

    const parts =
        email.split("@");

    if (parts.length !== 2) {
        return email;
    }

    const username =
        parts[0];

    const domain =
        parts[1];


    if (username.length <= 2) {

        return "*".repeat(username.length)
            + "@"
            + domain;

    }


    return username.charAt(0)
        + "*".repeat(username.length - 2)
        + username.charAt(username.length - 1)
        + "@"
        + domain;

}


/* =========================================================
   DISPLAY EMAIL
========================================================= */

if (email) {

    userEmail.textContent =
        email;

}


/* =========================================================
   OTP INPUT BEHAVIOR
========================================================= */

otpInputs.forEach(function (input, index) {


    /* -----------------------------------------------------
       Enter digit
    ------------------------------------------------------ */

    input.addEventListener("input", function () {

        this.value =
            this.value
                .replace(/\D/g, "")
                .slice(0, 1);


        if (
            this.value &&
            index < otpInputs.length - 1
        ) {

            otpInputs[index + 1].focus();

        }

    });


    /* -----------------------------------------------------
       Keyboard navigation
    ------------------------------------------------------ */

    input.addEventListener("keydown", function (event) {

        if (
            event.key === "Backspace" &&
            !this.value &&
            index > 0
        ) {

            otpInputs[index - 1].focus();

        }

    });


    /* -----------------------------------------------------
       Paste complete OTP
    ------------------------------------------------------ */

    input.addEventListener("paste", function (event) {

        event.preventDefault();


        const pastedData =
            event.clipboardData
                .getData("text")
                .replace(/\D/g, "")
                .slice(0, 6);


        pastedData
            .split("")
            .forEach(function (digit, i) {

                if (otpInputs[i]) {

                    otpInputs[i].value =
                        digit;

                }

            });


        if (pastedData.length === 6) {

            otpInputs[5].focus();

        }

    });

});


/* =========================================================
   GET OTP
========================================================= */

function getOTP() {

    let otp = "";


    otpInputs.forEach(function (input) {

        otp += input.value;

    });


    return otp;

}


/* =========================================================
   SHOW MESSAGE
========================================================= */

function showMessage(text, type) {

    message.textContent =
        text;

    message.className =
        "message " + type;

}


/* =========================================================
   VERIFY OTP
========================================================= */

verifyButton.addEventListener(
    "click",
    async function () {


        const otp =
            getOTP();


        /* -------------------------------------------------
           Validate OTP length
        -------------------------------------------------- */

        if (otp.length !== 6) {

            showMessage(
                "Please enter the complete 6-digit OTP.",
                "error"
            );

            return;

        }


        /* -------------------------------------------------
           Validate email
        -------------------------------------------------- */

        if (!email) {

            showMessage(
                "No reset email was found. Please start again.",
                "error"
            );

            return;

        }


        /* -------------------------------------------------
           Disable button
        -------------------------------------------------- */

        verifyButton.disabled = true;

        verifyButton.textContent =
            "Verifying...";


        message.className =
            "message";


        try {


            /* ---------------------------------------------
               Send OTP to Flask backend
            ---------------------------------------------- */

            const response =
                await fetch(
                    `${API_BASE}/api/forgot-password/verify-otp`,
                    {

                        method: "POST",

                        headers: {
                            "Content-Type": "application/json"
                        },

                        credentials: "include",

                        body: JSON.stringify({

                            email: email,

                            otp: otp

                        })

                    }
                );


            const data =
                await response
                    .json()
                    .catch(function () {
                        return {};
                    });


            /* ---------------------------------------------
               Backend rejected OTP
            ---------------------------------------------- */

            if (!response.ok) {

                throw new Error(
                    data.message ||
                    data.error ||
                    "Invalid or expired OTP."
                );

            }

            if (data.reset_token) {
                sessionStorage.setItem("resetToken", data.reset_token);
            }


            /* ---------------------------------------------
               OTP verified
            ---------------------------------------------- */

            showMessage(
                data.message ||
                "OTP verified successfully.",
                "success"
            );


            /* ---------------------------------------------
               Redirect to password reset
            ---------------------------------------------- */

            setTimeout(function () {

                window.location.href =
                    "../shared/set-password.html";

            }, 1000);


        } catch (error) {


            console.error(
                "OTP verification error:",
                error
            );


            showMessage(
                error.message ||
                "Unable to verify OTP.",
                "error"
            );


            verifyButton.disabled =
                false;

            verifyButton.textContent =
                "Verify OTP";

        }

    }
);


/* =========================================================
   COUNTDOWN TIMER
========================================================= */

let timeLeft = 120;

let countdown;


function startTimer() {


    clearInterval(countdown);


    timeLeft = 120;

    resendButton.disabled =
        true;


    timerElement.textContent =
        "02:00";


    countdown =
        setInterval(function () {


            const minutes =
                Math.floor(timeLeft / 60);


            const seconds =
                timeLeft % 60;


            timerElement.textContent =
                String(minutes).padStart(2, "0")
                + ":"
                + String(seconds).padStart(2, "0");


            if (timeLeft <= 0) {


                clearInterval(countdown);


                timerElement.textContent =
                    "Expired";


                resendButton.disabled =
                    false;


                return;

            }


            timeLeft--;

        }, 1000);

}


/* Start timer */

startTimer();


/* =========================================================
   RESEND OTP
========================================================= */

resendButton.addEventListener(
    "click",
    async function () {


        if (!email) {

            showMessage(
                "No reset email was found. Please start again.",
                "error"
            );

            return;

        }


        resendButton.disabled =
            true;

        resendButton.textContent =
            "Sending...";


        try {


            /*
             * NOTE:
             * This requires a resend endpoint on the backend.
             */

            const response =
                await fetch(
                    `${API_BASE}/api/forgot-password/resend-otp`,
                    {

                        method: "POST",

                        headers: {
                            "Content-Type": "application/json"
                        },

                        credentials: "include",

                        body: JSON.stringify({

                            email: email

                        })

                    }
                );


            const data =
                await response
                    .json()
                    .catch(function () {
                        return {};
                    });


            if (!response.ok) {

                throw new Error(
                    data.message ||
                    data.error ||
                    "Unable to resend OTP."
                );

            }


            showMessage(
                data.message ||
                "A new OTP has been sent to your email.",
                "success"
            );


            /* Restart timer */

            startTimer();


        } catch (error) {


            console.error(
                "Resend OTP error:",
                error
            );


            showMessage(
                error.message ||
                "Unable to resend OTP.",
                "error"
            );


            resendButton.disabled =
                false;

            resendButton.textContent =
                "Resend OTP";

        }

    }
);

